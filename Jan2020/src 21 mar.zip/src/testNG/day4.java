package testNG;

import org.testng.annotations.Test;

public class day4 {
	
	@Test
	public void WebLoginHomeLoan()
	{
		System.out.println("Web Login Home loan");
	}
	
	@Test
	public void MobileLoginHomeLoan()
	{
		System.out.println("Mobile LOgin Home  loan");
	}
	
	@Test
	public void APILoginHomeLoan()
	{
		System.out.println("API Login Home  loan");
	}
	

	
}
