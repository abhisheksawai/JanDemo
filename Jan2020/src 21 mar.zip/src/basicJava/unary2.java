package basicJava;

public class unary2 {
	
	public static void main(String[] args) {		
		
		int num1 = 10;
		num1 = num1--;
		num1 = num1-- + num1--;
		System.out.println(num1);  //
		

//		int num2 = 20;
//		num2 = num2++ + num2++;
//		System.out.println(num2);  //
		
	}

}
