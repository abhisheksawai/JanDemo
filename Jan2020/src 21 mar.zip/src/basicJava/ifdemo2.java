package basicJava;

public class ifdemo2 {
	
	public static void main(String[] args) {
		
		int per =30;		
		if(per > 35)
		{
			System.out.println("pass");
		}
		
		else
		{
			System.out.println("else part");
		}
	}
}
