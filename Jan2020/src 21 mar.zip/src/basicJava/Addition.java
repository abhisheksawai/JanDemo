package basicJava;

public class Addition {
	
	public static void main(String[] args) {
		
		
		int num1 = 10;
		int num2 = 4;
		int total;
		
		total = num1+num2;
		System.out.println(total);		
		
		//total = Addition(num1,num2);
		
	}

}
