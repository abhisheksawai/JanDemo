package janTestng;

public class mukeshMain extends mukeshTestng {

	public static void main(String[] args) {
		
		System.out.println("anything");
		
		mukeshMain m = new mukeshMain();
		m.testcase1();
	}
}
