package janTestng;

import org.testng.annotations.Test;

public class mukeshTestng {
	
	@Test
	public void testcase1()
	{
		System.out.println("TC01");
		ForAbhijeet.abhimethod();
	}

}
