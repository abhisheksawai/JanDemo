package janTestng;

public class ForAbhijeet {
	
	public static void abhimethod()
	{
		System.out.println("abhimethod");
	}

}
