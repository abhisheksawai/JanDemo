package keywordsdemo;

public class staticmehotdemo {
	
	public void m1()
	{
		System.out.println("m1");
	}
	
	public static void main(String[] args) {
		
		
	}

}
