package pckForTestng;

import org.testng.annotations.Test;

public class TestNGOne {
	
	@Test
	public void TC01Accountopen()
	{
		System.out.println("TC01");
	}
	
	@Test
	public void TC02accoutnclose()
	{
		System.out.println("TC02");
	}
	
	@Test
	public void TC03depositemoney()
	{
		
		System.out.println("TC03");
	}

}
