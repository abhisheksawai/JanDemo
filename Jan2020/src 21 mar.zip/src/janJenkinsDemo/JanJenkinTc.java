package janJenkinsDemo;

import org.testng.annotations.Test;


public class JanJenkinTc {
	
	@Test
	public void jenkinTc01()
	{
		System.out.println("jenkinTc01 - One");
	}
	
	@Test
	public void jenkinTc02()
	{
		System.out.println("jenkinTc02 - One");
	}

}
