package janJenkinsDemo;

import org.testng.annotations.Test;


public class JanJenkinTc2 {
	
	@Test
	public void jenkinTc01()
	{
		System.out.println("jenkinTc01 - Two");
	}
	
	@Test
	public void jenkinTc02()
	{
		System.out.println("jenkinTc02 - Two");
	}

}
