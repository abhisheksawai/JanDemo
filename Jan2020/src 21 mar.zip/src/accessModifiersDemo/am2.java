package accessModifiersDemo;

public class am2 {
	
	 int i =10;
	
	 void m1()
	{
		System.out.println("m1");
	}

	
	
}
