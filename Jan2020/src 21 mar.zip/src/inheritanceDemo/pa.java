package inheritanceDemo;

public class pa extends grandpa{
	
	public void paa()
	{
		System.out.println("paa");
	}

}
