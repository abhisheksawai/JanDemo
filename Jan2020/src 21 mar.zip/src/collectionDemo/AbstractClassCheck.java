package collectionDemo;

public abstract class AbstractClassCheck {
	
	public AbstractClassCheck()
	
	{
		System.out.println("a");
	}

}
