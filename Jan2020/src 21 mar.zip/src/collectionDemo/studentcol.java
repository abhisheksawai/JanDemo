package collectionDemo;

public class studentcol {
	
	int roll;
	String name;
	
	public studentcol(int roll, String name)
	{
		this.roll = roll;
		this.name = name;
	}

	
	
}
