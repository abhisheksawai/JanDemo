package collectionDemo;

public class array2 {
	
	public static void main(String[] args) {
		
		int i=100;
		System.out.println(i);
		
		int loannumver[] = {10,20,30,40};
		
		int b[]=new int[3];//declaration and instantiation  
		b[0]=106;
		b[1]=119;
		b[2]=229;
	//	b[3] = 434;
	//	b[4] =33;
		
	System.out.println(b[0]);
	System.out.println(b[1]);
	System.out.println(b[2]);
//	System.out.println(b[3]);
	//System.out.println(b[4]);
				
		
	}

}
