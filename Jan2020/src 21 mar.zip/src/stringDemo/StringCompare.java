package stringDemo;

public class StringCompare {
	
	public static void main(String[] args) {
		
		String s="Sachin";  
		System.out.println(s);
		String s1="Sachin";
		System.out.println(s1);
		String s2 = "kuchaur";
		
		System.out.println("-------");
		
		System.out.println(s.equals(s1));
		
		
	}

}
