package stringDemo;

public class ImmutableString2 {
	
	public static void main(String[] args) {
		
		String s="Sachin";  
		System.out.println(s);
		String s1=s.concat("cricket");
		System.out.println(s1);
		
	}

}
