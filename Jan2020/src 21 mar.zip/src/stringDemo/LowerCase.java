package stringDemo;

public class LowerCase {
	
	public static void main(String[] args) {
		
		String s="Abhishek";  
		System.out.println("original string->"+s);
		System.out.println(s.toLowerCase());
	
		
	}

}
