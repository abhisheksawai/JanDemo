package abstractionInterfaceDemo;

public abstract class carBrand extends FourWheeler {

	
	
}
