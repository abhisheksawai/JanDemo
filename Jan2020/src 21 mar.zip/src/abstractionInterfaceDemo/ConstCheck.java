package abstractionInterfaceDemo;

public abstract class ConstCheck {
	
	public ConstCheck()
	{
		System.out.println("B");
	}
	
	public void m1()
	{
		System.out.println("m1");
	}

}
