package abstractionInterfaceDemo;

public interface two extends one {
	
	public void t21();
	public void t22();

}
