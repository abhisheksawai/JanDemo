package abstractionInterfaceDemo;

public interface webInterface {
	
	public void w1();
	public void w2();

}
