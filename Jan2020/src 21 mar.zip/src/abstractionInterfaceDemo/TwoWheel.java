package abstractionInterfaceDemo;

public interface TwoWheel {
	
	public abstract void color();
	public void engine();
	
	public static void t2()
	{
		System.out.println("t2");
	}
	
}
