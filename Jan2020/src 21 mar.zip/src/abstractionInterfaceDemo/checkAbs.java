package abstractionInterfaceDemo;

public class checkAbs {
	
	public void m1() {
		System.out.println("m1");
	}
	
	public abstract void m2();

}
