package abstractionInterfaceDemo;

public interface three {
	
	public void t31();
	public void t32();

}
