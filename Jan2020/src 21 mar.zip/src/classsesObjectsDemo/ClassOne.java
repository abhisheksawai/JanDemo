package classsesObjectsDemo;

public class ClassOne {
	
	int roll;

}
