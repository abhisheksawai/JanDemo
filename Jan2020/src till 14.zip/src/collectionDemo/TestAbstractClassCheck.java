package collectionDemo;

public class TestAbstractClassCheck extends AbstractClassCheck {
	
	public TestAbstractClassCheck()
	{
		System.out.println("t");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TestAbstractClassCheck t = new TestAbstractClassCheck();

	}

}
