package collectionDemo;

public class typecastdemo {
	
	public static void main(String[] args) {
		
		//2 byte
		int x = 'a';  // char 1 byte
		System.out.println(x);
	}

}
