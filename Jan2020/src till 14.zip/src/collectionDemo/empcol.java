package collectionDemo;

public class empcol {
	
	int eno;
	String ename;
	
	public empcol(int eno, String ename)
	{
		this.eno = eno;
		this.ename = ename;
	}

}
