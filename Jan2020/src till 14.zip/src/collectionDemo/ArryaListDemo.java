package collectionDemo;

import java.util.ArrayList;

public class ArryaListDemo {
	
	public static void main(String[] args) {
		
		ArrayList al = new ArrayList();
		al.add("abhishek");
		al.add(10);
		al.add('Y');
		al.add("abhishek");
		al.add(null);
	//	al.add(al);
		
		System.out.println(al);
		
	}

}
