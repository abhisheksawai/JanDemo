package collectionDemo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ArryaListDemo12 {
	
	public static void main(String[] args) {
		
		ArrayList al = new ArrayList();
	
		al.add(10); //1   //al.add((Integer.valueof(10));  
		al.remove(10);
	
		System.out.println(al);
				
	}

}
