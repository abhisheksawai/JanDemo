package collectionDemo;

public class wrapperdemo {
	
	public static void main(String[] args) {
		
		int a =380;
		Integer i = Integer.valueOf(a); // i m telling to do
		System.out.println(i);
		
		int b =3380;
		Integer j = b;
		System.out.println(j); // did the boxing
		
		Integer d = 100;
		int e;
		e=d;
		System.out.println(e);
		
	}

}
