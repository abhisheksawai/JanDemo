package collectionDemo;

public class emp {
	
	int empid;
	String name;
	
	emp(int e, String n)
	{
		empid = e;
		name=n;
	}

}
