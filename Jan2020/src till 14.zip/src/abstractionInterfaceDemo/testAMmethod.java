package abstractionInterfaceDemo;

import accessModifiersDemo.am3;

public class testAMmethod extends am3  {

	public static void main(String[] args) {
		
		am3 a = new am3();
		
	//	a.m1();
		
		testAMmethod tm = new testAMmethod();
		tm.m1();
		
		
	}
	
}
