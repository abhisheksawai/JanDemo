package abstractionInterfaceDemo;

public class fireClass implements webInterface {	
	
	public void fireown()
	{
		System.out.println("fire own");
	}
	
	public void w1() {
		System.out.println("w1-fire");
	}

	public void w2() {
		System.out.println("w2-fire");
	}

}
