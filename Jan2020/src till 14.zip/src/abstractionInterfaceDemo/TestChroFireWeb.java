package abstractionInterfaceDemo;

public class TestChroFireWeb  {

	public static void main(String[] args) {
		
		chroClass c = new chroClass();
		c.w1();
		c.w2();
		c.chrowon();
		
		fireClass f = new fireClass();
		f.w1();
		f.w2();
		f.fireown();

		webInterface w = new chroClass();
		w.w1();
		w.w2();
		w.chro
	//	w.chrowon();
		
		//webInterface w3 = new webInterface();
		
		
		
	}

}
