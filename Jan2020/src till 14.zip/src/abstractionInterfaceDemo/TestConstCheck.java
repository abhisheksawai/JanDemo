package abstractionInterfaceDemo;

public class TestConstCheck extends ConstCheck {
	

	public TestConstCheck()
	{
		System.out.println("A");
	}
	
	public static void main(String[] args) {
	
		//ConstCheck karunpahu = new ConstCheck();
		TestConstCheck tc = new TestConstCheck();
		
	}

}
