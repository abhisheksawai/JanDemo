package accessModifiersDemo;

public class am3 {
	
	 int i =10;
	
	protected void m1()
	{
		System.out.println("m1");
	}

	
	
}
