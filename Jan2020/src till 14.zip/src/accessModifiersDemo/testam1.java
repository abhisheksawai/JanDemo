package accessModifiersDemo;

public class testam1 {
	
	public static void main(String[] args) {
		
		am1 a = new am1();
		a.m1();
		System.out.println(a.i);
	}

}
