package stringDemo;

public class ImmutableString {
	
	public static void main(String[] args) {
		
		String s="Sachin";  
		System.out.println(s);
		s=s.concat("cricket");
		System.out.println(s);
		
	}

}
