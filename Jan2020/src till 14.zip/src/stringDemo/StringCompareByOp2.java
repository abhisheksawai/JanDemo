package stringDemo;

public class StringCompareByOp2 {
	
	public static void main(String[] args) {
		
		String s= new String("sachin");  
		System.out.println(s);
		String s1="sachin";
		System.out.println(s1);
				
		System.out.println("-------");
		
		System.out.println(s==s1);
		
		
	}

}
