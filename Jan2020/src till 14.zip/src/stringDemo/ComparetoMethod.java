package stringDemo;

public class ComparetoMethod {
	
	public static void main(String[] args) {
		
		String s1="abhijeet";  
		String s2="bbhijeet";  
		String s3="abhijeet";  
		String s4="abhijeet";  
		
		System.out.println(s1.compareTo(s2));
		
	}

}
