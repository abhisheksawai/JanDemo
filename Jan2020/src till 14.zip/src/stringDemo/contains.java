package stringDemo;

public class contains {
	
	public static void main(String[] args) {
		
		String s="abhijeet is online";  
		String check = "is";
		System.out.println(s.contains(check));
		
		
	}

}
