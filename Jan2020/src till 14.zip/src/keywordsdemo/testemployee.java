package keywordsdemo;

public class testemployee {
	
	public static void main(String[] args) {
		
//		employee e1 = new employee(101,"abhishek");	
//		employee e2 = new employee(102,"Rutuja");	
//		employee e3 = new employee(103,"abhijit");	
//		
		employee e1 = new employee();
		employee e3 = new employee();
		employee e2 = new employee();
		
		
//		e1.display();
//		e2.display();
//		e3.display();
//		
		//	e.e1();
		//e.employee();
		
		
		staticmethoddemo2 sd2 = new staticmethoddemo2();
		sd2.m1();
	//	sd2.m2();
	
		staticmethoddemo2.m2(); // calling static method here m2 is static method
		
	}

}
