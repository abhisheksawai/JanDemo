package keywordsdemo;

public class employee {
	
	int num;
	String name;
	String gender;

public employee()
{
	System.out.println("e1");
}
	
//	public employee(int i, String string ) {		
//		num=i;
//		name=string;
//	}

	public void display()
	{
		System.out.println(num+" --"+name);
	}
	
	public void e1()
	{
		System.out.println("e1");
	}
}
