package inheritanceDemo;

public class cat extends animal {
	
	public void mew()
	{
		System.out.println("mew");
	}

}
