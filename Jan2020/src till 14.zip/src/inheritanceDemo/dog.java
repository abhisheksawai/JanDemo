package inheritanceDemo;

public class dog extends animal {
	
	public void bark()
	{
		System.out.println("bark");
	}
	
	
}
