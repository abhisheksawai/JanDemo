package classsesObjectsDemo;

public class firstClass {
	
	public static void main(String[] args) {
		
		
		
		
	}
	
	
	
	

}
