package classsesObjectsDemo;

import basicJava.Addition;

public class testStudent3 {
	
	
	public static void main(String[] args) {
		
		Student2 s5 = new Student2();
		s5.pushdata(303, "sneha");		
		s5.display();
		
		System.out.println(s5.rollno);
		System.out.println(s5.name);
	
		
}
}