package basicJava;

public class ifdemo1 {
	
	public static void main(String[] args) {
		
		int per =30;		
		if(per > 35)
		{
			System.out.println("pass");
		}
		
		if(per == 40)
		{
			System.out.println("same");
		}
				
		if(per < 35)
		{
			System.out.println("fail");
		}
	}
}
