package basicJava;

public class SecondJava {
	
	public static void main(String[] args) {
		
	}

}
