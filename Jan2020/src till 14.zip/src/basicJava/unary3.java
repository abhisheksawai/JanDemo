package basicJava;

public class unary3 {
	
	public static void main(String[] args) {		
		
		int num1 = 10;
		System.out.println(++num1);
		
	}

}
