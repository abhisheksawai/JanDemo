package basicJava;

public class unary6 {
	
	public static void main(String[] args) {		
		
		int num1 = 10;
		num1++;  //num1 = num1+1;
		System.out.println(num1);
		int num2=20;
		num2 = num2+1;
		System.out.println(num2);
		
	
	}

}
