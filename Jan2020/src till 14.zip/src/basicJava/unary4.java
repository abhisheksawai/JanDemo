package basicJava;

public class unary4 {
	
	public static void main(String[] args) {		
		
		int num1 = 10;
		System.out.println(num1++); //10
		System.out.println(num1);
		System.out.println(++num1);  //11
		
	}

}
