package basicJava;

public class FirstJava {

	public static void main(String[] args) {
		
		System.out.println("welcome Jan2020 batch");		
	}

}
