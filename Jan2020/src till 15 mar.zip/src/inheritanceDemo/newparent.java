package inheritanceDemo;

public class newparent extends newgrandpa {
	
	public void newpa()
	{
		System.out.println("newpa- change by rutuja");
	}
	
	public void onemore()
	{
		System.out.println("one more from p");
	}

}
