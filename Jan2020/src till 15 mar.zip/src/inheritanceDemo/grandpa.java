package inheritanceDemo;

public class grandpa {
	
	public void gp()
	{
		System.out.println("grandpa");
	}

}
