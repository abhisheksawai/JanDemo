package inheritanceDemo;

public class parent {
	
	public void property()
	{
		System.out.println("2bhk for my kid");
	}
	
	
	public void shadi()
	{
		System.out.println("arrange");
	}

}
