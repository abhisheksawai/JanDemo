package inheritanceDemo;

public class newgrandpa {
	
	public void newg()
	{
		System.out.println("newg");
	}

}
