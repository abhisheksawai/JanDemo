package inheritanceDemo;

public class animal {
	
	public void sleep()
	{
		System.out.println("animal");
	}

}
