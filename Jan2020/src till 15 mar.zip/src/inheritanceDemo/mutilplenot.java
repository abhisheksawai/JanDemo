package inheritanceDemo;

public class mutilplenot extends dog
public class mutilplenot extends cat

{

}
