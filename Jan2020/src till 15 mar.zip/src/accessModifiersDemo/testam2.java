package accessModifiersDemo;

public class testam2 {
	
	public static void main(String[] args) {
		
		am2 a = new am2();
		a.m1();
		System.out.println(a.i);
	}

}
