package classsesObjectsDemo;

import basicJava.Addition;

public class testStudent2 {
	
	
	public static void main(String[] args) {
		
		int num1=10;
	
	Student s5 = new Student();
	//s5.addrecord(106,"Parag");
	s5.insertdata(1079, "kapil");
	
	s5.pushdata(303, "sneha");
	
	System.out.println(s5.rollno);
	System.out.println(s5.name);

	Student s8= new Student();

	s8.rollno = 909;
	s8.name = "prachi";
	
	//first way to create and initialise
	
	
	
}
}