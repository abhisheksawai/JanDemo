package classsesObjectsDemo;

import basicJava.Addition;

public class testStudent {
	
	
	public static void main(String[] args) {s2.rollno = 104;
	s2.name = "Narayan";
	System.out.println(s2.rollno);
	System.out.println(s2.name);
	
	Student s3 = new Student();
	s3.rollno = 105;
	s3.name = "puja";
	System.out.println(s3.rollno);
	System.out.println(s3.name);}

}
