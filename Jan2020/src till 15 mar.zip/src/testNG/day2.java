package testNG;

import org.testng.annotations.Test;

public class day2 {
	
	@Test
	public void GOOD()
	{
		System.out.println("GOOD");
	}

	
}
