package testNG;

import org.testng.annotations.Test;

public class day3 {
	
	@Test
	public void WebLoginCarLoan()
	{
		System.out.println("Web Login Car loan");
	}
	
	@Test
	public void MobileLoginCarLoan()
	{
		System.out.println("Mobile LOgin Car loan");
	}
	
	@Test
	public void APILoginCarLoan()
	{
		System.out.println("API Login Car loan");
	}
	

	
}
