package collectionDemo;

public class wheeler {
	
	public void wheel()
	{
		System.out.println("wheel");
	}

}
