package keywordsdemo;

public class Animal {
	
	String color = "white";

	public void Animal()
	{
		System.out.println("animal method");
	}

	public Animal()
	{
		System.out.println("animal defualt cons");
	}

}
