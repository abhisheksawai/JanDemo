package abstractionInterfaceDemo;

public abstract class FourWheeler {
	
	public abstract void glass();
	public abstract void enginetype();
	public abstract void withdraw();
//	public abstract void addition();
	
	public void substaction()
	{
		System.out.println("substraction functionality");
	}
	
}
