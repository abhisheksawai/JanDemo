package abstractionInterfaceDemo;

public class chroClass implements webInterface {
	
	public void chrowon()
	{
		System.out.println("chro own");
	}

	
	public void w1() {
		System.out.println("w1-chro");
		
	}

	public void w2() {
		System.out.println("w2-chro");
		
	}

}
