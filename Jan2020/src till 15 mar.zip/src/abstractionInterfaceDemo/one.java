package abstractionInterfaceDemo;

public interface one {
	
	public void o1();
	public void o2();

}
