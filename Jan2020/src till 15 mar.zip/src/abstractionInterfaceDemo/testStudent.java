package abstractionInterfaceDemo;

public class testStudent {
	
	public static void main(String[] args) {
		student s1 = new student();
		s1.pushdata(100, "prachi");
		s1.printdata();
		
	}
	
	}
