package abstractionInterfaceDemo;

public class TestCarBrand {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		carBrand cb = new carBrand() {
			
			@Override
			public void withdraw() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void glass() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void enginetype() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void maruti() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void audi() {
				// TODO Auto-generated method stub
				
			}
		};
		
	}

}
