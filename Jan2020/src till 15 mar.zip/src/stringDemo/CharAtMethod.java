package stringDemo;

public class CharAtMethod {
	
	public static void main(String[] args) {
		
		String s="abhijeet";  
		char ch = s.charAt(2);
		System.out.println(ch);
		
		
	}

}
