package stringDemo;

public class StringCompare2Igonrecase {
	
	public static void main(String[] args) {
		
		String s="SACHIN";  
		System.out.println(s);
		String s1="sachin";
		System.out.println(s1);
				
		System.out.println("-------");
		
		System.out.println(s.equalsIgnoreCase(s1));
		
		
	}

}
