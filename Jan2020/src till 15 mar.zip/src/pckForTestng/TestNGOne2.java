package pckForTestng;

import org.testng.annotations.Test;

public class TestNGOne2 {
	
	@Test
	public void z()
	{
		System.out.println("TestNGOne2-TC01");
	}
	
	@Test
	public void x()
	{
		System.out.println("TestNGOne2-TC02");
	}
	
	@Test
	public void y()
	{
		System.out.println("TestNGOne2-TC03");
	}

}
