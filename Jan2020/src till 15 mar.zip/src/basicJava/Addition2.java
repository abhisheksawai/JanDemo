package basicJava;

public class Addition2 {
	
	public static void main(String[] args) {
		
		
		int num1 = 10;
		int num2 = 4;
		int total;
		
		total = num1-num2;
	//	System.out.println("substraction of 2 number is -> "+total);
	//	System.out.println("substraction of 2 number is -> "+total);
	//	System.out.println(total"is the substraction"); -
	//	System.out.println(+total"is the substraction");
	System.out.println(total+ " is the substraction"); 
	//		
		//System.out.println(total);		
		
		//total = Addition(num1,num2);
		
	}

}
