package basicJava;

public class ifdemo3 {
	
	public static void main(String[] args) {
		
		int per =30;		
		if(per > 35)
		{
			System.out.println("pass");
		}		
		else if(per > 35)
		{
			System.out.println("else part");
		}
		else
		{
			
		}
		
	}
}
