package basicJava;

public class forloopDemo {

	public static void main(String[] args) {
		
		
	//	for(initiallisation ; condition ; increment/decrement)
		//{
			//statement
		//}
		
		for(int i=10; i<=13 ; i++)
		{
			System.out.println("welcome jan batch");
			System.out.println(i);
		}
	
		
		

	}

}
