package janTestng;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNGOne2 {
	
	@Test
	public void z()
	{
		System.out.println("TC01");
	}
	
	@Test
	public void x()
	{
		System.out.println("TC02");
	}
	
	@Test
	public void y()
	{
		System.out.println("TC03");
	}

}
